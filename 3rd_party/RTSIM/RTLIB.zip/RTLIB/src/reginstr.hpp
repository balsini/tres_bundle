#ifndef __REGINSTR_HPP__
#define __REGINSTR_HPP__

namespace RTSim {
    void __reginstr_init();
    void __regsched_init();
    void __regtask_init();
}

#endif
